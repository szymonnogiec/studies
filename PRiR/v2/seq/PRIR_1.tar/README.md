Zadanie nr 1 z PRiR
TEMAT: Zadanie BK27. Słownik równoległy
Szymon Nogieć

Kompilacja:
mkdir bin && cd bin
cmake ..
make

Plik wynikowy to "seq" uruchamiany bez parametrów;