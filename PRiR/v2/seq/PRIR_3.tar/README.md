TEMAT: Zadanie BK27. Słownik równoległy
Szymon Nogieć
PRIR Etap 3
MPI

``` Kompilacja:
mkdir bin && cd bin
cmake ..
make
```
Plik wynikowy to "mpi_prir" uruchamiany poprzez
```
 mpirun -n 4 ./mpi_prir
 ```
 gdzie n to liczba procesorów