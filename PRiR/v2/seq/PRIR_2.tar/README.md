##### Zadanie nr 1 z PRiR
    * abcd

[link to my github](https://github.com)

### This is my table
First column | Second column
---|---
elo raz dwa trzy | elo dwa trzy cztery
end this is | very
nice way to | edit code

:+1: :sparkles: :camel: :octocat: :metal:

TEMAT: Zadanie BK27. Słownik równoległy
Szymon Nogieć

``` Kompilacja:
mkdir bin && cd bin
cmake ..
make
```
Plik wynikowy to "seq" uruchamiany bez parametrów;