
TEMAT: Zadanie BK27. Słownik równoległy
Szymon Nogieć

``` Kompilacja:
mkdir bin && cd bin
cmake ..
make
```
Plik wynikowy to "openmp_prir" uruchamiany bez parametrów;
